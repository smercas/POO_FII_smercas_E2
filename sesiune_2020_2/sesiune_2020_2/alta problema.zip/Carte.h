#pragma once
#include <string>

class Carte {
public:
	virtual std::string GetInfo() = 0;
};
